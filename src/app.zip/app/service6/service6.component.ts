import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service6',
  templateUrl: './service6.component.html',
  styleUrls: ['./service6.component.css']
})
export class Service6Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
